# Exotic Sounds website (West Palm Beach)

A single page site: `index.html` plus the `img/` folder. No build step.
Shop details used: 2789 Forest Hill Blvd, West Palm Beach, FL 33406 · (561) 633-0829 ·
Mon-Fri 9 AM-6 PM, Sat 9 AM-4 PM, Sun closed (from the Google listing, October 2026).

## 1. Connect the quote form (Formspree)

1. Sign up at https://formspree.io using the email the shop wants quote requests sent to.
2. Create a new form. Formspree gives you an endpoint like `https://formspree.io/f/abcdwxyz`.
3. Open `index.html`, search for `YOUR_FORM_ID`, and replace that URL with your endpoint:
   `const FORMSPREE_ENDPOINT = 'https://formspree.io/f/abcdwxyz';`
4. Upload the site, send a test request, and confirm it in the Formspree email.

Each request arrives with: name, phone, email (if given), vehicle, services, budget,
preferred contact (call / text / email), message, and the language the customer used.
If sending ever fails, the customer sees their details with buttons to text or call the shop instead.

## 2. Put it online

Any static host works. Fastest: drag the `exotic-sounds-site` folder onto https://app.netlify.com/drop.
GitHub Pages and Cloudflare Pages also work. Then point the shop's domain at the host.
Their Google listing currently links to Facebook; once the site is live, update the "Website" field there.

## 3. Before launch

- **Photos**: every photo in `img/` is an Unsplash stock photo. Swap in the shop's real work
  (keep the same file names) and the site updates with no code changes.
- **Confirm with the shop**: that they install CarPlay units, that "family-owned" is right
  (it comes from their reviews), the service list, and the hours.
- **Live numbers**: the 4.8 rating, 328 reviews and the review-topic counts are from October 2026.
  Update them in `index.html` now and then (search for `328` and `topics__list`).

## Editing text

All English and Spanish text lives in the `STR` object near the top of the main script in `index.html`
(`en: {...}` and `es: {...}`). Change a line in both languages.
